from core.context import SessionState

def generate_analytics_summary(state: SessionState) -> dict:
    """
    Generates analytics summary based on the current session state.
    """
    total = state.total_tasks_count
    completed = state.completed_tasks_count
    skipped = len(state.skipped_tasks)
    
    return {
        "progress_percentage": state.progress_percentage,
        "completed_tasks": completed,
        "total_tasks": total,
        "skipped_tasks_count": skipped,
        "status": "Ahead" if state.progress_percentage > 50 else "On Track"
    }
