import json
import os
import tempfile
from typing import Optional
from core.context import SessionState
from config.settings import settings
from utils.logger import get_logger

logger = get_logger(__name__)

# Fallback in-memory storage if files are read-only
_in_memory_sessions = {}

class FilePersistence:
    """
    JSON based persistence for SessionState.
    Auto-detects read-only environments (like Vercel/Netlify) and routes to 
    writable /tmp directory or falls back to robust in-memory storage.
    """
    def __init__(self, file_path: str = settings.session_store_path):
        # On Vercel/Netlify, relocate store to writable /tmp directory
        if "VERCEL" in os.environ or "NETLIFY" in os.environ or not os.access(".", os.W_OK):
            self.file_path = os.path.join(tempfile.gettempdir(), "sessions.json")
            logger.info(f"Read-only filesystem detected. Session store moved to: {self.file_path}")
        else:
            self.file_path = file_path

    async def load(self, session_id: str) -> Optional[SessionState]:
        # Try loading from file first
        if os.path.exists(self.file_path):
            try:
                with open(self.file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    session_data = data.get(session_id)
                    if session_data:
                        return SessionState(**session_data)
            except Exception as e:
                logger.error(f"Error loading session {session_id} from file: {e}")
        
        # Fallback to memory
        if session_id in _in_memory_sessions:
            logger.debug(f"Loaded session {session_id} from in-memory cache")
            return SessionState(**_in_memory_sessions[session_id])
            
        return None

    async def save(self, state: SessionState):
        # Save to memory cache first
        _in_memory_sessions[state.session_id] = state.model_dump()
        
        # Try writing to the filesystem
        try:
            data = {}
            if os.path.exists(self.file_path):
                try:
                    with open(self.file_path, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                except Exception:
                    pass
            
            data[state.session_id] = state.model_dump()
            
            with open(self.file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4)
            logger.debug(f"Saved session {state.session_id} to file persistence")
        except Exception as e:
            # Fall back silently to memory only in serverless sandboxes
            logger.warning(f"File write failed (Read-only filesystem?): {e}. Kept session in memory cache.")
