from core.context import SessionState, Context
from memory.persistence import FilePersistence
from utils.logger import get_logger

logger = get_logger(__name__)

class SessionManager:
    """
    Manages loading, creating, and saving sessions.
    """
    def __init__(self):
        self.persistence = FilePersistence()

    async def get_or_create_context(self, session_id: str) -> Context:
        state = await self.persistence.load(session_id)
        if not state:
            logger.info(f"Creating new session state for {session_id}")
            state = SessionState(session_id=session_id)
        return Context(state=state)

    async def save_context(self, context: Context):
        # Update derived metrics before saving
        context.state.update_progress()
        await self.persistence.save(context.state)
        logger.info(f"Session {context.state.session_id} saved successfully.")
