from core.context import Context
from core.events import EventBus, Event
from core.agent import BaseAgent
from memory.session_manager import SessionManager
from utils.logger import get_logger

logger = get_logger(__name__)

class Runner:
    """
    Orchestrates agents, context, and events.
    """
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.event_bus = EventBus()
        self.session_manager = SessionManager()
        self.agents = {}
        self.context = None

    async def initialize(self):
        """Load context for the session."""
        self.context = await self.session_manager.get_or_create_context(self.session_id)

    def register_agent(self, agent_class, *args, **kwargs):
        """Registers an agent into the runner."""
        agent = agent_class(event_bus=self.event_bus, *args, **kwargs)
        self.agents[agent.name] = agent
        return agent

    async def run_interaction(self, primary_agent_name: str, user_input: str) -> str:
        """
        Runs a single interaction loop using the primary agent.
        """
        if not self.context:
            await self.initialize()

        agent = self.agents.get(primary_agent_name)
        if not agent:
            raise ValueError(f"Agent {primary_agent_name} not registered.")

        logger.info(f"Routing input to {primary_agent_name}")
        
        # In a real ADK, we might emit a PRE_PROCESS event here
        await self.event_bus.publish(Event(type="PRE_PROCESS", payload={"user_input": user_input}))
        
        try:
            response = await agent.process(self.context, user_input)
        except Exception as e:
            logger.error(f"Agent {primary_agent_name} failed: {e}")
            response = f"I'm sorry, I encountered an internal error: {e}"

        # Save context state after interaction
        await self.session_manager.save_context(self.context)
        return response
