# Multi-Agent Academic Concierge System

An enterprise-grade, async Multi-Agent Concierge System built with Python 3.12 and Google's Gemini 2.0 Flash.

## Architecture

This project implements an Agent Development Kit (ADK) pattern using:
- **Runner**: Orchestrates agent interactions and event loops.
- **Context/SessionState**: Shared Pydantic data models for typed state management.
- **EventBus**: Async pub/sub for inter-agent communication.
- **Agents**: 
  - `ConciergeAgent`: Primary user interface.
  - `PlannerAgent`: Syllabus parsing and schedule generation.
  - `EvaluatorAgent`: Adaptive schedule recalculation.

## Setup Instructions

1. Ensure you have Python 3.12+ installed.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Configure Environment Variables:
   Copy `.env.example` to `.env` and add your Google Gemini API Key.
   ```bash
   cp .env.example .env
   # Edit .env and set GEMINI_API_KEY
   ```

## Running the Application

Start the CLI interactive session:
```bash
python main.py
```

### Example Commands
- **"plan syllabus"**: Triggers the `PlannerAgent` to parse a dummy syllabus and generate a schedule.
- **"today"**: Shows tasks for the current day.
- **"complete"**: Marks the first pending task for today as completed.
- **"progress"**: Shows your current analytics.
- **"skip"**: Triggers the `EvaluatorAgent` to adjust your schedule.

## Future Extensibility
The `EventBus` and `BaseAgent` architecture makes it trivial to add new agents (e.g., `QuizGeneratorAgent`, `MotivationCoachAgent`) by registering them in the `Runner` and subscribing them to relevant events.
