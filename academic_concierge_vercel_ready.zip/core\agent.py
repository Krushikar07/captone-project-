from abc import ABC, abstractmethod
from google import genai
from core.context import Context
from core.events import EventBus
from config.settings import settings
from utils.logger import get_logger

logger = get_logger(__name__)

class BaseAgent(ABC):
    """
    Abstract base agent conforming to ADK patterns.
    """
    def __init__(self, name: str, event_bus: EventBus):
        self.name = name
        self.event_bus = event_bus
        # Initialize Gemini client
        self.client = genai.Client(api_key=settings.gemini_api_key)
        # Using Gemini 3.5 Flash to bypass exhausted free tier limits on earlier models
        self.model_id = 'gemini-3.5-flash'
    
    @abstractmethod
    async def process(self, context: Context, user_input: str) -> str:
        """
        Process the user input using the provided context.
        Returns the agent's string response.
        """
        pass

    def get_system_instruction(self) -> str:
        return "You are an AI assistant."
