import json
import asyncio
from google import genai
from pydantic import BaseModel, Field
from typing import List
from config.settings import settings
from utils.logger import get_logger

logger = get_logger(__name__)

class TopicSchema(BaseModel):
    name: str
    complexity: int = Field(description="Estimated complexity from 1 to 5")

class UnitSchema(BaseModel):
    name: str
    topics: List[TopicSchema]

class SyllabusSchema(BaseModel):
    units: List[UnitSchema]

async def parse_syllabus(syllabus_text: str) -> dict:
    """
    Uses Gemini 2.0 Flash to intelligently parse a raw syllabus text into 
    units, chapters, and topics with complexity scores.
    """
    if not syllabus_text or len(syllabus_text.strip()) < 10:
        logger.warning("Empty or very short syllabus provided.")
        return {"units": []}

    client = genai.Client(api_key=settings.gemini_api_key)
    
    prompt = (
        "You are an expert academic curriculum parser. Extract the units and topics from the provided text. "
        "Even if the text is messy, unstructured, or missing explicit 'Unit' headers, logically group the subjects into generic Units (e.g., 'Unit 1: Fundamentals'). "
        "For each topic, assign a complexity score from 1 (very easy) to 5 (very complex). "
        "If you absolutely cannot find any academic content, return a single generic Unit with a generic Topic."
        f"\n\nSyllabus Data:\n\n{syllabus_text}"
    )

    try:
        import asyncio
        for attempt in range(3):
            try:
                response = await client.aio.models.generate_content(
                    model='gemini-3.5-flash',
                    contents=prompt,
                    config=genai.types.GenerateContentConfig(
                        response_mime_type="application/json",
                        response_schema=SyllabusSchema,
                        temperature=0.2,
                    ),
                )
                result = json.loads(response.text)
                return result
            except Exception as e:
                if "429" in str(e) and attempt < 2:
                    await asyncio.sleep(4)
                else:
                    raise e
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Failed to parse syllabus with Gemini: {error_msg}")
        if "429" in error_msg or "RESOURCE_EXHAUSTED" in error_msg:
            return {"units": [], "error": "RATE_LIMIT"}
        # Graceful fallback
        return {"units": [], "error": "PARSE_ERROR"}

def estimate_topic_complexity(topic_dict: dict) -> int:
    """
    Extracts the complexity from the parsed dictionary, defaulting to 3.
    """
    return topic_dict.get("complexity", 3)
