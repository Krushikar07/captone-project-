import os
import base64

def embed():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    public_dir = os.path.join(current_dir, "public")
    output_file = os.path.join(current_dir, "static_content.py")
    
    files = {
        "INDEX_HTML": "index.html",
        "PLANNER_HTML": "planner.html",
        "HISTORY_HTML": "history.html",
        "ABOUT_HTML": "about.html",
        "STYLES_CSS": "styles.css",
        "APP_JS": "app.js"
    }
    
    print("Generating static_content.py...")
    with open(output_file, "w", encoding="utf-8") as out:
        out.write("# This file is auto-generated. Do not edit directly.\n\n")
        for key, filename in files.items():
            path = os.path.join(public_dir, filename)
            if not os.path.exists(path):
                print(f"Error: {path} does not exist.")
                continue
            with open(path, "rb") as f:
                content = f.read()
                b64 = base64.b64encode(content).decode("utf-8")
                out.write(f'{key} = "{b64}"\n\n')
    print("Embedded static files successfully.")

if __name__ == "__main__":
    embed()
