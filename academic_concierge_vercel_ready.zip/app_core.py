import os
import json
import asyncio
import tempfile
from datetime import datetime, date, timedelta
from typing import Optional
from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Header
from fastapi.responses import JSONResponse, HTMLResponse, Response
import base64
from pydantic import BaseModel
from dotenv import load_dotenv

# Construct absolute path to .env file so Vercel can find it
_env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
load_dotenv(_env_path)

# Try multiple common env var names in case of typo in Vercel dashboard
OPENROUTER_API_KEY = (
    os.environ.get("OPENROUTER_API_KEY") or
    os.environ.get("openrouter_api_key") or
    "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"
)


app = FastAPI(title="SmartCourse Capstone API")

# ── Health check endpoint ──
@app.get("/health")
async def health():
    key = (
        os.environ.get("OPENROUTER_API_KEY") or
        os.environ.get("openrouter_api_key") or
        "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"
    )
    return JSONResponse({
        "status": "ok",
        "api_key_set_statically": bool(OPENROUTER_API_KEY),
        "api_key_set_dynamically": bool(key),
        "api_key_preview": (key[:8] + "...") if key else "NOT SET"
    })


# In-memory session cache (survives warm serverless instances)
_sessions: dict = {}

# OpenRouter model fallback chain (free-tier model slugs)
MODELS = [
    "openrouter/free",
    "meta-llama/llama-3.3-70b-instruct:free",
    "deepseek/deepseek-r1:free",
]

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"

# ─────────────────────────────────────────
# AI helper (OpenRouter, OpenAI-compatible API)
# ─────────────────────────────────────────
async def call_ai(prompt: str, system: str = "", client_key: str = "") -> str:
    key = (
        client_key.strip() or
        os.environ.get("OPENROUTER_API_KEY") or
        os.environ.get("openrouter_api_key") or
        "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"
    )
    if not key:
        return "⚠️ No API key configured. Please set OPENROUTER_API_KEY in Vercel environment variables, or add your key in the ⚙️ Settings panel in the top bar."
    try:
        from openai import AsyncOpenAI

        client = AsyncOpenAI(api_key=key, base_url=OPENROUTER_BASE_URL)
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        for model in MODELS:
            for attempt in range(2):
                try:
                    response = await client.chat.completions.create(
                        model=model,
                        messages=messages,
                        temperature=0.7,
                        max_tokens=1500,
                    )
                    return response.choices[0].message.content.strip()
                except Exception as e:
                    err = str(e)
                    if "429" in err or "503" in err or "rate" in err.lower():
                        await asyncio.sleep(1.5)
                        break
                    raise e
    except Exception as e:
        return f"⚠️ AI temporarily unavailable: {str(e)[:120]}. Please try again in a moment."
    return "⚠️ All AI models are currently busy. Please try again in a few seconds."

# ─────────────────────────────────────────
# Session helpers
# ─────────────────────────────────────────
def _session_path(session_id: str) -> str:
    return os.path.join(tempfile.gettempdir(), f"cap_{session_id}.json")

def get_session(session_id: str) -> dict:
    if session_id in _sessions:
        return _sessions[session_id]
    path = _session_path(session_id)
    if os.path.exists(path):
        try:
            with open(path) as f:
                data = json.load(f)
                if "conversations" not in data:
                    data["conversations"] = {}
                _sessions[session_id] = data
                return data
        except Exception:
            pass

    new = {
        "session_id": session_id,
        "milestones": {},
        "progress_pct": 0.0,
        "total_tasks": 0,
        "completed_tasks": 0,
        "syllabus_raw": None,
        "conversations": {}
    }
    _sessions[session_id] = new
    return new

def save_session(session_id: str, data: dict):
    _sessions[session_id] = data
    try:
        with open(_session_path(session_id), "w") as f:
            json.dump(data, f)
    except Exception:
        pass

def log_message(session_id: str, conversation_id: str, role: str, text: str):
    session = get_session(session_id)
    if "conversations" not in session:
        session["conversations"] = {}
    if conversation_id not in session["conversations"]:
        session["conversations"][conversation_id] = {
            "conversation_id": conversation_id,
            "title": text[:30] + "..." if len(text) > 30 else text,
            "created_at": datetime.utcnow().isoformat() + "Z",
            "last_message_at": datetime.utcnow().isoformat() + "Z",
            "messages": []
        }
    
    conv = session["conversations"][conversation_id]
    
    # Auto-title on the first user message
    if role == "user" and len(conv.get("messages", [])) == 0:
        cleaned_title = text.strip().replace("\n", " ")
        cleaned_title = cleaned_title[:30] + "..." if len(cleaned_title) > 30 else cleaned_title
        conv["title"] = cleaned_title
        
    conv["messages"].append({
        "role": role,
        "text": text,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    })
    conv["last_message_at"] = datetime.utcnow().isoformat() + "Z"
    save_session(session_id, session)



def recalc(session: dict):
    total = done = 0
    for tasks in session["milestones"].values():
        total += len(tasks)
        done  += sum(1 for t in tasks if t.get("done"))
    session["total_tasks"]     = total
    session["completed_tasks"] = done
    session["progress_pct"]    = round(done / total * 100, 1) if total else 0.0

# ─────────────────────────────────────────
# Chat endpoint
# ─────────────────────────────────────────
class ChatRequest(BaseModel):
    session_id: str
    message: str
    conversation_id: Optional[str] = None

class ChatResponse(BaseModel):
    response: str

class SyncRequest(BaseModel):
    session_id: str
    state: dict

SYSTEM = (
    "You are a friendly, encouraging, and supportive AI Academic Concierge. "
    "Always greet the user warmly, be polite, nice, and helpful. Encourage them in their studies. "
    "Keep answers relatively concise but conversational and polite.\n\n"
    "CRITICAL ROUTING & OUTPUT RULES:\n"
    "1. If the user wants to plan, schedule, or create a curriculum for a syllabus (or if they paste a syllabus/ask to learn a topic), you MUST write a friendly, nice reply in natural language outlining the plan, and then at the very end of your response, append the exact token [TRIGGER_PLANNER] followed by a structured JSON representation of the units and topics. Use this exact format:\n"
    "[TRIGGER_PLANNER]\n"
    "{\n"
    "  \"units\": [\n"
    "    {\n"
    "      \"name\": \"Unit Name\",\n"
    "      \"topics\": [\"Topic 1\", \"Topic 2\"]\n"
    "    }\n"
    "  ]\n"
    "}\n"
    "Do NOT include markdown code fences around the JSON. Do NOT include any text after the JSON.\n\n"
    "2. If the user wants to mark a task as done/complete, confirm it politely and append the exact token [MARK_COMPLETE] at the very end of your response."
)

def is_planning_request(msg: str) -> bool:
    msg_lower = msg.lower()
    planning_keywords = [
        "plan", "schedule", "syllabus", "curriculum", "course", 
        "planner", "timeline", "roadmap", "study plan", "study guide", 
        "roadmap", "learn python", "learn html", "learn css", 
        "learn javascript", "make a plan to learn"
    ]
    if any(keyword in msg_lower for keyword in planning_keywords):
        exclude_words = ["explain", "detail", "what is", "show", "view", "current", "how does", "why did", "struggle", "help me with"]
        if any(w in msg_lower for w in exclude_words):
            return False
        return True
    return False

def is_complete_request(msg: str) -> bool:
    msg_lower = msg.lower()
    return "mark" in msg_lower and ("done" in msg_lower or "complete" in msg_lower or "finish" in msg_lower)

def is_json_response(text: str) -> bool:
    cleaned = text.strip()
    if cleaned.startswith("{") and "units" in cleaned.lower():
        return True
    if "```json" in cleaned or "```" in cleaned:
        if "units" in cleaned.lower() and ("{" in cleaned or "[" in cleaned):
            return True
    if '"units"' in cleaned or "'units'" in cleaned:
        return True
    return False

def extract_json(raw: str) -> Optional[dict]:
    import re
    cleaned = raw.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r'^```(?:json)?\s*', '', cleaned)
        cleaned = re.sub(r'\s*```$', '', cleaned)
    
    s = cleaned.find("{")
    e = cleaned.rfind("}") + 1
    if s != -1 and e != -1 and s < e:
        json_str = cleaned[s:e]
        try:
            return json.loads(json_str)
        except Exception:
            try:
                json_str = json_str.replace("'", '"')
                json_str = re.sub(r',\s*([\]}])', r'\1', json_str)
                return json.loads(json_str)
            except Exception:
                pass
    return None

@app.post("/chat", response_model=ChatResponse)
async def chat(
    request: ChatRequest,
    x_openrouter_api_key: Optional[str] = Header(None)
):
    client_key = x_openrouter_api_key or ""
    user_id = request.session_id
    
    session = get_session(user_id)
    conversation_id = request.conversation_id
    if conversation_id:
        if conversation_id not in session.get("conversations", {}):
            raise HTTPException(status_code=404, detail="Conversation not found in this session")
    else:
        convs = list(session.get("conversations", {}).keys())
        if convs:
            conversation_id = convs[0]
        else:
            import uuid
            conversation_id = "conv_" + uuid.uuid4().hex[:12]

    def log_msg(role: str, text: str):
        log_message(user_id, conversation_id, role, text)
            
    # Log user message
    log_msg("user", request.message)
    
    try:
        session = get_session(user_id)
        lower   = request.message.lower().strip()
        today   = date.today().isoformat()
 
        # ── Local handlers (zero API) ──────────────────
        if lower in {"hello", "hi", "hey", "hii", "helo", "hiya"}:
            reply = (
                "Hello! 👋 I'm your Academic Concierge.\n\n"
                "Here's what I can do:\n"
                "• 📚 Plan your syllabus — paste it and say 'plan my syllabus'\n"
                "• 📅 Check today's tasks — say 'what is my plan for today'\n"
                "• ✅ Mark tasks done — say 'mark task as done'\n"
                "• 📊 Check progress — say 'show my progress'\n"
                "• 💬 Answer any question — just ask!\n\nWhat would you like to do?"
            )
            log_msg("assistant", reply)
            return ChatResponse(response=reply)
 
        if any(k in lower for k in ["today", "plan for today", "schedule today", "what to study"]):
            tasks = session["milestones"].get(today, [])
            if not session["milestones"]:
                reply = "You don't have a schedule yet! Paste your syllabus and say 'plan my syllabus'."
            elif not tasks:
                reply = "No tasks scheduled for today. Enjoy your break! 🎉"
            else:
                lines = ["✅ " + t["topic"] + f" (~{t['minutes']}m)" if t.get("done") else "📖 " + t["topic"] + f" (~{t['minutes']}m)" for t in tasks]
                done = sum(1 for t in tasks if t.get("done"))
                reply = f"**Today's Study Plan ({today}):**\n\n" + "\n".join(lines) + f"\n\n📊 {done}/{len(tasks)} tasks completed."
            log_msg("assistant", reply)
            return ChatResponse(response=reply)
 
        if any(k in lower for k in ["progress", "how am i doing", "percentage", "stats"]):
            if not session["milestones"]:
                reply = "No schedule yet! Upload a syllabus to get started."
            else:
                reply = (
                    f"📊 **Your Study Progress:**\n\n"
                    f"• Overall: **{session['progress_pct']}%** complete\n"
                    f"• Tasks Done: **{session['completed_tasks']}/{session['total_tasks']}**\n"
                    f"• Days Planned: **{len(session['milestones'])}**"
                )
            log_msg("assistant", reply)
            return ChatResponse(response=reply)
 
        # ── Gemini call (Conversational Assistant) ─────
        ctx = {
            "has_schedule": bool(session["milestones"]),
            "progress_pct": session["progress_pct"],
            "today": today,
        }
        text = await call_ai(
            f"User: {request.message}\nContext: {json.dumps(ctx)}",
            SYSTEM,
            client_key
        )

        # ── Route triggers based on AI response ────────
        is_planning = "[TRIGGER_PLANNER]" in text or is_json_response(text)
        if is_planning:
            try:
                # First attempt: Try to parse JSON directly from the initial response (single call)
                parsed = extract_json(text)
                units = parsed.get("units", []) if (parsed and isinstance(parsed, dict)) else []
                total_topics_count = sum(len(u.get("topics", [])) for u in units) if units else 0
                
                # Fallback: if no JSON was embedded in the first response, perform the secondary parser API call
                if total_topics_count == 0:
                    parse_prompt = (
                        "You are a curriculum parser. Parse the syllabus below into structured JSON.\n"
                        "Return ONLY valid JSON, no explanation:\n"
                        "{\"units\": [{\"name\": \"Unit Name\", \"topics\": [\"Topic 1\", \"Topic 2\"]}]}\n\n"
                        f"Syllabus:\n{text}"
                    )
                    raw = await call_ai(parse_prompt, client_key=client_key)
                    if not ("⚠️" in raw or "Error" in raw or "No API key" in raw):
                        parsed = extract_json(raw)
                        units = parsed.get("units", []) if (parsed and isinstance(parsed, dict)) else []
                        
                        # Resilient line-by-line parser as fallback for secondary call
                        if not units:
                            current_unit = None
                            for line in raw.split("\n"):
                                line = line.strip()
                                if not line:
                                    continue
                                if any(x in line.lower() for x in ["unit", "week", "chapter", "module"]) or line.endswith(":"):
                                    current_unit = {"name": line.strip(":-*•# "), "topics": []}
                                    units.append(current_unit)
                                elif current_unit is not None:
                                    cleaned_line = line.strip("-*•# 1234567890. ")
                                    if cleaned_line:
                                        current_unit["topics"].append(cleaned_line)
                                else:
                                    cleaned_line = line.strip("-*•# 1234567890. ")
                                    if cleaned_line:
                                        current_unit = {"name": "General Syllabus", "topics": [cleaned_line]}
                                        units.append(current_unit)

                # Count again
                total_topics_count = sum(len(u.get("topics", [])) for u in units) if units else 0
                if total_topics_count == 0:
                    reply = (
                        "I'm sorry, I had some trouble organizing that syllabus into a study plan. "
                        "Could you please paste the syllabus text directly or upload a PDF/text file? "
                        "I'll be happy to try planning it again for you! 📚"
                    )
                    log_msg("assistant", reply)
                    return ChatResponse(response=reply)

                # Build milestones
                milestones: dict = {}
                idx = 0
                for unit in units:
                    for topic in unit.get("topics", []):
                        day = (date.today() + timedelta(days=idx % 14)).isoformat()
                        milestones.setdefault(day, []).append({
                            "topic": f"{unit['name']}: {topic}",
                            "minutes": 60,
                            "done": False,
                        })
                        idx += 1
                session["milestones"] = milestones
                session["syllabus_raw"] = request.message[:500]
                recalc(session)
                save_session(user_id, session)
 
                total_tasks = session['total_tasks']
                total_days = len(milestones)
                weeks_str = f"about {total_days // 7} weeks" if total_days >= 7 else f"{total_days} days"
                
                # Get first day's tasks
                first_day = sorted(milestones.keys())[0] if milestones else None
                first_day_tasks = milestones.get(first_day, []) if first_day else []
                
                task_lines = []
                for t in first_day_tasks:
                    clean_topic = t['topic']
                    if ": " in clean_topic:
                        clean_topic = clean_topic.split(": ", 1)[1]
                    task_lines.append(f"• {clean_topic} (~{t['minutes']}m)")
                task_list_str = "\n".join(task_lines)
 
                # Construct the friendly message, stripping JSON block out of the original response
                friendly_reply = text
                if "[TRIGGER_PLANNER]" in friendly_reply:
                    friendly_reply = friendly_reply.split("[TRIGGER_PLANNER]", 1)[0].strip()
                elif "{" in friendly_reply:
                    friendly_reply = friendly_reply.split("{", 1)[0].strip()

                # Fallback if friendly reply was wiped out/too short
                if len(friendly_reply) < 20:
                    friendly_reply = (
                        "I've mapped out a full learning path for you! 🎓 "
                        f"It has **{total_tasks} topics** organized across **{weeks_str}**. "
                        "Here is what to start with on your first day:\n\n"
                        f"{task_list_str}\n\n"
                        "You can see your entire personalized roadmap anytime in the 📅 **Schedule** tab. "
                        "Let's get started on your learning journey! 🚀"
                    )

                log_msg("assistant", friendly_reply)
                return ChatResponse(response=friendly_reply)
            except Exception as ex:
                import traceback
                traceback.print_exc()
                reply = (
                    "I'm sorry, I had some trouble organizing that syllabus into a study plan. "
                    "Could you please paste the syllabus text directly or upload a PDF/text file? "
                    "I'll be happy to try planning it again for you! 📚"
                )
                log_msg("assistant", reply)
                return ChatResponse(response=reply)
 
        elif "[MARK_COMPLETE]" in text:
            tasks = session["milestones"].get(today, [])
            for t in tasks:
                if not t.get("done"):
                    t["done"] = True
                    recalc(session)
                    save_session(user_id, session)
                    reply = f"✅ Marked **'{t['topic']}'** as complete!\n📊 Overall progress: **{session['progress_pct']}%**"
                    log_msg("assistant", reply)
                    return ChatResponse(response=reply)
            reply = "No pending tasks found for today!"
            log_msg("assistant", reply)
            return ChatResponse(response=reply)
 
        log_msg("assistant", text)
        return ChatResponse(response=text)
 
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ─────────────────────────────────────────
# Analytics endpoint
# ─────────────────────────────────────────
@app.get("/analytics/{session_id}")
async def get_analytics(session_id: str):
    session = get_session(session_id)
    history = []
    for conv in session.get("conversations", {}).values():
        history.extend(conv.get("messages", []))
    history.sort(key=lambda x: x.get("timestamp", ""))
    today_str = date.today().isoformat()
    
    # ── Calculate engagement metrics ──
    user_dates = sorted(list(set(msg["timestamp"][:10] for msg in history if msg.get("role") == "user")))
    total_messages = sum(1 for msg in history if msg.get("role") == "user")
    active_days = len(user_dates)
    
    # Streak calculation
    streak = 0
    if user_dates:
        date_objs = sorted(list(set(date.fromisoformat(d) for d in user_dates)), reverse=True)
        today = date.today()
        yesterday = today - timedelta(days=1)
        if date_objs[0] == today or date_objs[0] == yesterday:
            streak = 1
            current = date_objs[0]
            for next_date in date_objs[1:]:
                if (current - next_date).days == 1:
                    streak += 1
                    current = next_date
                elif (current - next_date).days == 0:
                    continue
                else:
                    break

    # ── Topic struggle detection ──
    STOP_WORDS = {
        "what", "does", "mean", "explain", "again", "still", "dont", "don't", "get", "confused", "how", "why", "who", "where", "when",
        "please", "can", "you", "help", "me", "understand", "i", "am", "stuck", "on", "in", "at", "for", "with", "about", "the", "a", "an",
        "this", "that", "these", "those", "is", "are", "was", "were", "to", "of", "and", "or", "but", "not", "my", "your", "his", "her",
        "syllabus", "plan", "planner", "study", "tasks", "task", "milestones", "milestone", "schedule", "course", "academic"
    }
    struggle_keywords = {}
    for msg in history:
        if msg.get("role") != "user":
            continue
        text = msg.get("text", "").lower()
        has_confusion = any(phrase in text for phrase in [
            "explain again", "still don't get", "dont get", "don't get", 
            "confused", "what does", "what is", "help me understand", 
            "difficult", "hard", "explain more", "stuck"
        ])
        words = [w.strip("?,.!:;\"'") for w in text.split()]
        for w in words:
            if len(w) > 3 and w not in STOP_WORDS:
                weight = 2.0 if has_confusion else 0.5
                struggle_keywords[w] = struggle_keywords.get(w, 0.0) + weight

    topics = [k for k, v in struggle_keywords.items() if v >= 2.0]
    topics = sorted(topics, key=lambda x: struggle_keywords[x], reverse=True)[:4]
    struggle_topics = [t.capitalize() for t in topics]

    # ── Procrastination nudge ──
    procrastination_nudge = None
    days_since_last_checkin = 0
    user_messages = [msg for msg in history if msg.get("role") == "user"]
    if user_messages:
        last_msg = user_messages[-1]
        last_date = date.fromisoformat(last_msg["timestamp"][:10])
        days_since_last_checkin = (date.today() - last_date).days
        if days_since_last_checkin > 2:
            procrastination_nudge = f"It's been {days_since_last_checkin} days since you last checked in. Time to get back to studying! 📖"

    # Days study plan
    days = []
    for day_str, tasks in sorted(session["milestones"].items()):
        total = len(tasks)
        done  = sum(1 for t in tasks if t.get("done"))
        days.append({
            "date": day_str,
            "total": total,
            "completed": done,
            "pending": total - done,
            "pct": round(done / total * 100 if total else 0, 1),
            "tasks": [{"topic": t["topic"], "minutes": t["minutes"], "done": t.get("done", False)} for t in tasks],
            "is_buffer": False,
            "is_revision": False,
        })
    
    return {
        "session_id":              session_id,
        "total_tasks":             session["total_tasks"],
        "completed_tasks":         session["completed_tasks"],
        "pending_tasks":           session["total_tasks"] - session["completed_tasks"],
        "progress_pct":            session["progress_pct"],
        "total_days":              len(session["milestones"]),
        "has_syllabus":            bool(session["milestones"]),
        "days":                    days,
        "total_messages":          total_messages,
        "active_days":             active_days,
        "streak":                  streak,
        "struggle_topics":         struggle_topics,
        "procrastination_nudge":   procrastination_nudge,
        "days_since_last_checkin": days_since_last_checkin
    }

# ── Upload endpoint ──
@app.post("/upload")
async def upload_file(
    session_id: str = Form(...),
    conversation_id: Optional[str] = Form(None),
    file: UploadFile = File(...),
    x_openrouter_api_key: Optional[str] = Header(None)
):
    try:
        content = await file.read()
        text_content = ""
        fname = file.filename.lower()

        if fname.endswith(".pdf"):
            try:
                import pypdf, io
                reader = pypdf.PdfReader(io.BytesIO(content))
                text_content = "\n".join(p.extract_text() or "" for p in reader.pages)
            except Exception:
                text_content = content.decode("utf-8", errors="ignore")
        elif fname.endswith((".png", ".jpg", ".jpeg")):
            text_content = "[Image received. For best results, please paste your syllabus text directly in the chat.]"
        else:
            text_content = content.decode("utf-8", errors="ignore")

        if not text_content.strip():
            return {"response": "Could not read the file. Please paste your syllabus text directly in the chat."}

        session = get_session(session_id)
        if conversation_id and conversation_id not in session.get("conversations", {}):
            raise HTTPException(status_code=404, detail="Conversation not found in this session")

        req = ChatRequest(session_id=session_id, conversation_id=conversation_id, message=f"plan syllabus with this text:\n{text_content[:4000]}")
        result = await chat(req, x_openrouter_api_key=x_openrouter_api_key)
        return {"response": result.response}
    except Exception as e:
        return {"response": f"Upload error: {str(e)}"}

# ─────────────────────────────────────────
# State endpoint
# ─────────────────────────────────────────
@app.get("/state/{session_id}")
async def get_state(session_id: str):
    return get_session(session_id)

@app.post("/session/sync")
async def sync_session(request: SyncRequest):
    session_id = request.session_id
    state = request.state
    if not session_id or state.get("session_id") != session_id:
        raise HTTPException(status_code=400, detail="Invalid session state payload")
    _sessions[session_id] = state
    save_session(session_id, state)
    return {"status": "success", "message": "Session state synced successfully."}

@app.get("/history/{session_id}")
async def get_history_legacy(session_id: str):
    session = get_session(session_id)
    convs = list(session.get("conversations", {}).values())
    if convs:
        convs.sort(key=lambda x: x.get("last_message_at", ""), reverse=True)
        return {"history": convs[0].get("messages", [])}
    return {"history": []}

@app.delete("/history/{session_id}")
async def delete_history_legacy(session_id: str):
    session = get_session(session_id)
    session["conversations"] = {}
    save_session(session_id, session)
    return {"status": "success", "message": "All conversations deleted."}

# ─────────────────────────────────────────
# Conversations endpoints
# ─────────────────────────────────────────
@app.post("/conversations/{session_id}")
async def create_conversation(session_id: str):
    import uuid
    session = get_session(session_id)
    conversation_id = "conv_" + uuid.uuid4().hex[:12]
    
    if "conversations" not in session:
        session["conversations"] = {}
        
    session["conversations"][conversation_id] = {
        "conversation_id": conversation_id,
        "title": "New Conversation",
        "created_at": datetime.utcnow().isoformat() + "Z",
        "last_message_at": datetime.utcnow().isoformat() + "Z",
        "messages": []
    }
    save_session(session_id, session)
    return {"conversation_id": conversation_id}

@app.get("/conversations/{session_id}")
async def list_conversations(session_id: str):
    session = get_session(session_id)
    convs = list(session.get("conversations", {}).values())
    # Sort most-recent-first using last_message_at
    convs.sort(key=lambda x: x.get("last_message_at", ""), reverse=True)
    return [
        {
            "conversation_id": c["conversation_id"],
            "title": c["title"],
            "created_at": c["created_at"],
            "last_message_at": c["last_message_at"]
        }
        for c in convs
    ]

@app.get("/conversations/{session_id}/{conversation_id}")
async def get_conversation(session_id: str, conversation_id: str):
    session = get_session(session_id)
    conv = session.get("conversations", {}).get(conversation_id)
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return conv

@app.delete("/conversations/{session_id}/{conversation_id}")
async def delete_conversation(session_id: str, conversation_id: str):
    session = get_session(session_id)
    if "conversations" in session and conversation_id in session["conversations"]:
        del session["conversations"][conversation_id]
        save_session(session_id, session)
        return {"status": "success", "message": f"Conversation {conversation_id} deleted."}
    raise HTTPException(status_code=404, detail="Conversation not found")

# ─────────────────────────────────────────
# Static files served directly from memory (base64-embedded)
# ─────────────────────────────────────────
import static_content

@app.get("/", response_class=HTMLResponse)
@app.get("/index.html", response_class=HTMLResponse)
async def get_index():
    return base64.b64decode(static_content.INDEX_HTML).decode("utf-8")

@app.get("/planner.html", response_class=HTMLResponse)
async def get_planner():
    return base64.b64decode(static_content.PLANNER_HTML).decode("utf-8")

@app.get("/history.html", response_class=HTMLResponse)
async def get_history_page():
    return base64.b64decode(static_content.HISTORY_HTML).decode("utf-8")

@app.get("/about.html", response_class=HTMLResponse)
async def get_about():
    return base64.b64decode(static_content.ABOUT_HTML).decode("utf-8")

@app.get("/styles.css")
async def get_styles():
    return Response(content=base64.b64decode(static_content.STYLES_CSS), media_type="text/css")

@app.get("/app.js")
async def get_app_js():
    return Response(content=base64.b64decode(static_content.APP_JS), media_type="application/javascript")



