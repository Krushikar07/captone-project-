import json
from datetime import date
from core.agent import BaseAgent
from core.context import Context, Task
from core.events import EventBus, Event
from tools.parser_tools import parse_syllabus, estimate_topic_complexity
from tools.planner_tools import generate_calendar
from utils.logger import get_logger

logger = get_logger(__name__)

class PlannerAgent(BaseAgent):
    """
    Curriculum Planner Agent.
    Responsible for parsing syllabus and generating the initial schedule.
    """
    def __init__(self, event_bus: EventBus, name: str = "PlannerAgent"):
        super().__init__(name=name, event_bus=event_bus)

    def get_system_instruction(self) -> str:
        return (
            "You are an expert Curriculum Planner Agent. "
            "Your task is to take syllabus text and generate a balanced schedule."
        )

    async def process(self, context: Context, user_input: str) -> str:
        logger.info("PlannerAgent is generating schedule...")
        
        # 1. Parse Syllabus (Using Gemini Tool)
        parsed_data = await parse_syllabus(user_input)
        
        if parsed_data.get("error") == "RATE_LIMIT":
            return "Your Gemini API Key has hit a rate limit (Quota Exceeded). Please wait about 30 to 60 seconds for your quota to reset and try again!"
            
        if not parsed_data.get("units"):
            return "I couldn't identify any units or topics in the syllabus you provided. Please provide a more detailed syllabus."
        
        # 2. Generate Empty Calendar (14 days)
        today = date.today()
        milestones = generate_calendar(today, 14)
        
        # 3. Distribute tasks (Balanced distribution logic)
        available_days = [d for d, plan in milestones.items() if not plan.is_buffer_day and not plan.is_revision_day]
        
        day_idx = 0
        for unit in parsed_data.get("units", []):
            for topic_data in unit.get("topics", []):
                if day_idx >= len(available_days):
                    # If we run out of days, start piling onto existing days
                    day_idx = 0 
                
                complexity = estimate_topic_complexity(topic_data)
                estimated_mins = complexity * 30
                topic_name = topic_data.get("name", "Unknown Topic")
                
                task = Task(topic=f"{unit.get('name', 'Unit')}: {topic_name}", estimated_minutes=estimated_mins, confidence_score=None)
                day_key = available_days[day_idx]
                milestones[day_key].tasks.append(task)
                
                day_idx += 1

        context.state.milestones = milestones
        context.state.syllabus_raw = user_input
        context.state.update_progress()
        
        await self.event_bus.publish(Event(type="PLANNING_COMPLETE", source_agent=self.name))
        
        return "I have successfully analyzed the syllabus with Gemini and generated your balanced 14-day schedule. You have buffer days and revision days assigned."
