import json
import asyncio
from datetime import date
from google import genai
from core.agent import BaseAgent
from core.context import Context
from core.events import EventBus, Event
from tools.analytics_tools import generate_analytics_summary
from utils.logger import get_logger

logger = get_logger(__name__)

# Model fallback chain — tries each model in order until one works
MODELS = [
    'gemini-2.0-flash',
    'gemini-3.5-flash',
    'gemini-2.0-flash-lite',
    'gemini-2.5-flash-lite',
]

class ConciergeAgent(BaseAgent):
    """
    Primary interface for the user.
    Handles common queries locally (no API needed), and uses Gemini with multi-model fallback for everything else.
    """
    def __init__(self, event_bus: EventBus, name: str = "ConciergeAgent"):
        super().__init__(name=name, event_bus=event_bus)

    def get_system_instruction(self) -> str:
        return (
            "You are a highly capable AI Academic Concierge. You can answer ANY questions the user asks — "
            "write code, explain concepts, solve problems, or just have a conversation. "
            "You ALSO manage the student's study schedule.\n\n"
            "SPECIAL COMMANDS — respond with EXACTLY these strings (no other text) when appropriate:\n"
            "- Reply [TRIGGER_PLANNER] if user wants to plan/analyze a syllabus or create a schedule.\n"
            "- Reply [MARK_COMPLETE] if user says they finished or completed a task.\n"
            "For all other inputs, respond naturally and helpfully like a world-class AI assistant."
        )

    def _handle_locally(self, lower_input: str, context: Context) -> str | None:
        """Handle common queries locally without any API call."""
        today_str = date.today().isoformat()

        # Greetings
        if lower_input.strip() in ["hello", "hi", "hey", "hii", "helo"]:
            return (
                "Hello! 👋 I'm your Academic Concierge, powered by Gemini AI.\n\n"
                "I can help you with:\n"
                "• 📚 **Planning your syllabus** — paste your syllabus and say 'plan it'\n"
                "• 📅 **Checking today's tasks** — say 'what is my plan for today'\n"
                "• ✅ **Marking tasks complete** — say 'mark task as done'\n"
                "• 📊 **Checking progress** — say 'show my progress'\n"
                "• 💬 **Answering any question** — ask me anything!\n\n"
                "What would you like to do?"
            )

        # Today's schedule — handled 100% locally, no API needed
        if any(k in lower_input for k in ["today", "plan for today", "schedule today", "what to study"]):
            plan = context.state.milestones.get(today_str)
            if not context.state.milestones:
                return "You don't have a schedule yet! Paste your syllabus and say 'plan my syllabus' to get started."
            if not plan or not plan.tasks:
                return "You have no tasks scheduled for today. Enjoy your break! 🎉"
            tasks_str = "\n".join([
                f"✅ {t.topic} (~{t.estimated_minutes}m)" if t.completed else f"📖 {t.topic} (~{t.estimated_minutes}m)"
                for t in plan.tasks
            ])
            completed = sum(1 for t in plan.tasks if t.completed)
            total = len(plan.tasks)
            return f"**Your Study Plan for Today ({today_str}):**\n\n{tasks_str}\n\n📊 Progress: {completed}/{total} tasks completed."

        # Progress check — local
        if any(k in lower_input for k in ["progress", "analytics", "how am i doing", "percentage"]):
            if not context.state.milestones:
                return "You don't have a schedule yet. Upload a syllabus to get started!"
            stats = generate_analytics_summary(context.state)
            return (
                f"📊 **Your Study Progress:**\n\n"
                f"• Overall: **{stats['progress_percentage']}%** complete\n"
                f"• Tasks Done: **{stats['completed_tasks']}/{stats['total_tasks']}**\n"
                f"• Status: **{stats['status']}**"
            )

        # Mark complete — local
        if any(k in lower_input for k in ["done", "complete", "finished", "completed"]):
            plan = context.state.milestones.get(today_str)
            if plan:
                for task in plan.tasks:
                    if not task.completed:
                        task.completed = True
                        context.state.update_progress()
                        return f"✅ Great work! Marked **'{task.topic}'** as completed!\n📊 Overall progress: **{context.state.progress_percentage}%**"
            return "No pending tasks found for today!"

        # Planner trigger — local routing
        if any(k in lower_input for k in ["plan", "syllabus", "schedule", "create plan", "study plan"]):
            return None  # Let Gemini handle to extract TRIGGER_PLANNER intent

        return None  # Not handled locally, needs Gemini

    async def _call_gemini(self, prompt: str, system_instruction: str) -> str:
        """Try each model in the fallback chain until one succeeds."""
        last_error = None
        for model in MODELS:
            for attempt in range(2):  # 2 attempts per model
                try:
                    logger.info(f"Trying model: {model} (attempt {attempt+1})")
                    response = await self.client.aio.models.generate_content(
                        model=model,
                        contents=prompt,
                        config=genai.types.GenerateContentConfig(
                            system_instruction=system_instruction,
                            temperature=0.7
                        )
                    )
                    logger.info(f"Success with model: {model}")
                    return response.text.strip()
                except Exception as e:
                    last_error = e
                    err_str = str(e)
                    if "429" in err_str or "503" in err_str or "UNAVAILABLE" in err_str:
                        logger.warning(f"Model {model} failed ({err_str[:80]}), trying next...")
                        await asyncio.sleep(1)
                        break  # Try next model
                    else:
                        raise e  # Non-recoverable error, bail out
        raise Exception(f"All models failed. Last error: {last_error}")

    async def process(self, context: Context, user_input: str) -> str:
        logger.info(f"ConciergeAgent processing input: {user_input}")
        lower_input = user_input.lower()

        # 1. Try to handle locally first (zero API calls)
        local_response = self._handle_locally(lower_input, context)
        if local_response:
            return local_response

        # 2. Build minimal context for Gemini (keep tokens low)
        state_summary = {
            "has_schedule": bool(context.state.milestones),
            "progress_pct": context.state.progress_percentage,
            "today_date": date.today().isoformat(),
        }
        if context.state.milestones and date.today().isoformat() in context.state.milestones:
            state_summary["today_tasks"] = [
                {"topic": t.topic, "done": t.completed}
                for t in context.state.milestones[date.today().isoformat()].tasks
            ]

        prompt = f"User: {user_input}\nState: {json.dumps(state_summary)}"

        # 3. Call Gemini with fallback chain
        try:
            text = await self._call_gemini(prompt, self.get_system_instruction())

            # 4. Route special commands
            if "[TRIGGER_PLANNER]" in text:
                await self.event_bus.publish(Event(type="TRIGGER_PLANNER", payload={"input": user_input}))
                if context.state.milestones:
                    return "✅ Your schedule has been successfully created! Say **'what is my plan for today'** to see your first tasks."
                else:
                    return "I tried to build the schedule but couldn't extract the topics. Please provide your syllabus text more clearly."

            if "[MARK_COMPLETE]" in text:
                today_str = date.today().isoformat()
                plan = context.state.milestones.get(today_str)
                if plan:
                    for task in plan.tasks:
                        if not task.completed:
                            task.completed = True
                            context.state.update_progress()
                            return f"✅ Marked **'{task.topic}'** as complete! Progress: **{context.state.progress_percentage}%**"
                return "No pending tasks found for today!"

            return text

        except Exception as e:
            logger.error(f"All Gemini models failed: {e}")
            return (
                "⚠️ I'm temporarily unable to reach the Gemini AI servers (all models are rate-limited or overloaded).\n\n"
                "**In the meantime, I can still help you locally:**\n"
                "• Say **'what is my plan for today'** to see your schedule\n"
                "• Say **'show my progress'** to see your stats\n"
                "• Say **'mark done'** to complete a task\n\n"
                "Please try again in 1-2 minutes for AI-powered answers!"
            )
