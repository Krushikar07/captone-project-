from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
from datetime import date

class Task(BaseModel):
    topic: str
    estimated_minutes: int
    completed: bool = False
    notes: Optional[str] = None
    confidence_score: Optional[int] = Field(None, ge=1, le=5)

class DayPlan(BaseModel):
    date: str # YYYY-MM-DD
    tasks: List[Task] = Field(default_factory=list)
    is_buffer_day: bool = False
    is_revision_day: bool = False

class SessionState(BaseModel):
    session_id: str
    syllabus_raw: Optional[str] = None
    milestones: Dict[str, DayPlan] = Field(default_factory=dict)
    completed_tasks_count: int = 0
    total_tasks_count: int = 0
    skipped_tasks: List[Task] = Field(default_factory=list)
    progress_percentage: float = 0.0
    total_tokens_used: int = 0
    user_preferences: Dict[str, Any] = Field(default_factory=dict)

    def update_progress(self):
        """Recalculate progress based on tasks in milestones."""
        total = 0
        completed = 0
        for day_plan in self.milestones.values():
            for task in day_plan.tasks:
                total += 1
                if task.completed:
                    completed += 1
        self.total_tasks_count = total
        self.completed_tasks_count = completed
        if total > 0:
            self.progress_percentage = round((completed / total) * 100, 2)
        else:
            self.progress_percentage = 0.0

class Context(BaseModel):
    """
    ADK Context passing mechanism. Holds the shared SessionState.
    """
    state: SessionState
