from pydantic import BaseModel
from typing import Any, Dict, Optional

class Event(BaseModel):
    """
    Base event class for agent communication.
    """
    type: str
    payload: Dict[str, Any] = {}
    source_agent: Optional[str] = None

class EventBus:
    """
    Simple async event bus for pub/sub between agents and runners.
    """
    def __init__(self):
        self.listeners = {}

    def subscribe(self, event_type: str, callback):
        if event_type not in self.listeners:
            self.listeners[event_type] = []
        self.listeners[event_type].append(callback)

    async def publish(self, event: Event):
        if event.type in self.listeners:
            for callback in self.listeners[event.type]:
                await callback(event)
