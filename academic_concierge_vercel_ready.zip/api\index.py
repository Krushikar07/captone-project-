import sys
import os

# Add project root to Python path so all imports resolve correctly on Vercel
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app_core import app
