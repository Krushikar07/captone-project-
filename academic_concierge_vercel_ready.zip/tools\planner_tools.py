from datetime import timedelta, date
from typing import Dict
from core.context import DayPlan, Task

def generate_calendar(start_date: date, days: int) -> Dict[str, DayPlan]:
    """
    Generates a blank calendar of DayPlans.
    """
    milestones = {}
    for i in range(days):
        current_date = start_date + timedelta(days=i)
        date_str = current_date.isoformat()
        
        # Simple heuristic: Every 7th day is a revision day, 6th day is buffer
        is_revision = (i + 1) % 7 == 0
        is_buffer = (i + 1) % 7 == 6
        
        milestones[date_str] = DayPlan(
            date=date_str,
            is_buffer_day=is_buffer,
            is_revision_day=is_revision
        )
    return milestones
