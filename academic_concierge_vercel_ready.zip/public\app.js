const sessionId = "session_" + Math.random().toString(36).substring(2, 9);

const inputField  = document.getElementById('chat-input');
const sendBtn     = document.getElementById('send-btn');
const chatBody    = document.getElementById('chat-history');
const fileUpload  = document.getElementById('file-upload');

// Auto-resize textarea
inputField.addEventListener('input', function () {
  this.style.height = 'auto';
  this.style.height = this.scrollHeight + 'px';
});

inputField.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
});

sendBtn.addEventListener('click', sendMessage);

// ── Add message ──
function addMsg(text, isUser = false) {
  const msg = document.createElement('div');
  msg.className = `chat-msg ${isUser ? 'user' : 'ai'}`;

  const role = document.createElement('div');
  role.className = 'msg-role';
  role.textContent = isUser ? 'YOU' : 'CONCIERGE';

  const bubble = document.createElement('div');
  bubble.className = 'msg-bubble';
  bubble.textContent = text;

  msg.appendChild(role);
  msg.appendChild(bubble);
  chatBody.appendChild(msg);
  chatBody.scrollTo({ top: chatBody.scrollHeight, behavior: 'smooth' });
}

// ── Typing indicator ──
function addTyping() {
  const msg = document.createElement('div');
  msg.className = 'chat-msg ai typing-msg';

  const role = document.createElement('div');
  role.className = 'msg-role';
  role.textContent = 'CONCIERGE';

  const bubble = document.createElement('div');
  bubble.className = 'msg-bubble';
  bubble.innerHTML = '<div class="typing-dots"><span class="t-dot"></span><span class="t-dot"></span><span class="t-dot"></span></div>';

  msg.appendChild(role);
  msg.appendChild(bubble);
  chatBody.appendChild(msg);
  chatBody.scrollTo({ top: chatBody.scrollHeight, behavior: 'smooth' });
  return msg;
}

// ── Send message ──
async function sendMessage() {
  const text = inputField.value.trim();
  if (!text) return;

  inputField.value = '';
  inputField.style.height = 'auto';
  addMsg(text, true);

  const typing = addTyping();

  try {
    const res = await fetch('/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: sessionId, message: text }),
    });
    const data = await res.json();
    chatBody.removeChild(typing);
    addMsg(res.ok ? data.response : 'Error: ' + data.detail);
  } catch (err) {
    chatBody.removeChild(typing);
    addMsg('Network error. Is the server running?');
  }
}

// ── File upload ──
fileUpload.addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;

  addMsg(`📎 ${file.name}`, true);
  const typing = addTyping();

  const fd = new FormData();
  fd.append('session_id', sessionId);
  fd.append('file', file);

  try {
    const res = await fetch('/upload', { method: 'POST', body: fd });
    const data = await res.json();
    chatBody.removeChild(typing);
    addMsg(data.response || 'File processed.');
  } catch (err) {
    chatBody.removeChild(typing);
    addMsg('Upload failed. Try again.');
  }

  fileUpload.value = '';
});


