from datetime import date
from core.agent import BaseAgent
from core.context import Context
from core.events import EventBus, Event
from utils.logger import get_logger

logger = get_logger(__name__)

class EvaluatorAgent(BaseAgent):
    """
    Adaptive Evaluator Agent.
    Monitors progress and shifts schedule if user falls behind or gets ahead.
    """
    def __init__(self, event_bus: EventBus, name: str = "EvaluatorAgent"):
        super().__init__(name=name, event_bus=event_bus)

    def get_system_instruction(self) -> str:
        return "You are an Adaptive Evaluator. You adjust the user's schedule intelligently."

    async def process(self, context: Context, user_input: str) -> str:
        logger.info("EvaluatorAgent is recalculating milestones...")
        
        today_str = date.today().isoformat()
        moved_tasks_count = 0
        
        # Intelligent shifting algorithm:
        # 1. Find all incomplete tasks from days PRIOR to today.
        # 2. Move them to future buffer days, prioritizing the earliest available buffer day.
        
        incomplete_tasks = []
        for date_key, plan in sorted(context.state.milestones.items()):
            if date_key < today_str:
                # Extract incomplete tasks and remove them from the past day
                for task in plan.tasks:
                    if not task.completed:
                        incomplete_tasks.append(task)
                        moved_tasks_count += 1
                plan.tasks = [t for t in plan.tasks if t.completed]
        
        if not incomplete_tasks:
            return "You are perfectly on track! No schedule adjustments were needed."
            
        # Distribute incomplete tasks to future buffer days
        future_buffer_days = [
            plan for date_key, plan in sorted(context.state.milestones.items())
            if date_key >= today_str and plan.is_buffer_day
        ]
        
        if not future_buffer_days:
            # Fallback: add to the last day if no buffer days exist
            last_day_key = sorted(context.state.milestones.keys())[-1]
            context.state.milestones[last_day_key].tasks.extend(incomplete_tasks)
        else:
            # Round robin distribution among buffer days
            idx = 0
            for task in incomplete_tasks:
                future_buffer_days[idx].tasks.append(task)
                idx = (idx + 1) % len(future_buffer_days)

        context.state.update_progress()
        
        await self.event_bus.publish(Event(type="EVALUATION_COMPLETE", source_agent=self.name))
        return f"I have adapted your schedule. I successfully moved {moved_tasks_count} past incomplete tasks to your upcoming buffer days to ensure you don't fall behind."
